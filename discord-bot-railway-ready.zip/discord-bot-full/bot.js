require('dotenv').config();
const { Client, GatewayIntentBits } = require('discord.js');
const fs = require('fs');
const fetch = require('node-fetch');

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

const githubApi = "https://api.github.com/repos/" + process.env.GITHUB_REPO + "/contents/" + process.env.GITHUB_FILE;

async function loadUserData() {
    const res = await fetch(githubApi, {
        headers: { Authorization: 'Bearer ' + process.env.GITHUB_TOKEN }
    });
    const json = await res.json();
    const content = Buffer.from(json.content, 'base64').toString();
    return JSON.parse(content || '{}');
}

async function saveUserData(data) {
    const res = await fetch(githubApi, {
        method: 'PUT',
        headers: {
            Authorization: 'Bearer ' + process.env.GITHUB_TOKEN,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            message: 'Update users.json',
            content: Buffer.from(JSON.stringify(data, null, 2)).toString('base64'),
            sha: (await fetch(githubApi, { headers: { Authorization: 'Bearer ' + process.env.GITHUB_TOKEN } })).json().then(r => r.sha)
        })
    });
    return res.ok;
}

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    const userData = await loadUserData();
    if (!userData[message.author.id]) {
        userData[message.author.id] = { name: message.author.username, messages: [] };
    }

    userData[message.author.id].messages.push(message.content);
    await saveUserData(userData);

    if (message.content.startsWith("!test")) {
        message.reply("Bot is working!");
    }
});

client.login(process.env.DISCORD_TOKEN);